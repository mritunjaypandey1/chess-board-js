var div = document.getElementById("chessboard");
for (var i = 0; i < 8; i++) {

    var ul = document.createElement('ul');
    div.appendChild(ul);
    
    ul.style.display = 'flex';
    
    for (var j = 0; j < 8; j++) {
        var li = document.createElement('li');
        ul.appendChild(li);
        li.style.width='80px'
         li.style.height='70px'
         li.style.listStyle='none';
        
    }
}